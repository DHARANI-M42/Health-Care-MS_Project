-- phpMyAdmin SQL Dump
-- version 5.1.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Apr 14, 2022 at 09:45 AM
-- Server version: 10.4.22-MariaDB
-- PHP Version: 7.4.27

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `hcmsdb`
--

-- --------------------------------------------------------

--
-- Table structure for table `appointments`
--

CREATE TABLE `appointments` (
  `appoint_id` int(10) NOT NULL,
  `app_from` int(30) NOT NULL,
  `app_to` int(25) NOT NULL,
  `phone` varchar(15) NOT NULL,
  `app_date` varchar(25) NOT NULL,
  `app_time` varchar(25) NOT NULL,
  `message` text NOT NULL,
  `status` varchar(30) NOT NULL DEFAULT 'Pending'
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `appointments`
--

INSERT INTO `appointments` (`appoint_id`, `app_from`, `app_to`, `phone`, `app_date`, `app_time`, `message`, `status`) VALUES
(1, 1, 3, '8888811111', '2022-04-14', '11:55', 'The patient Gokul wants to make an appointment with you sir. Its an emergency.', 'Accepted');

-- --------------------------------------------------------

--
-- Table structure for table `employee`
--

CREATE TABLE `employee` (
  `emp_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `uname` varchar(30) NOT NULL,
  `email` varchar(30) NOT NULL,
  `position` varchar(30) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `employee`
--

INSERT INTO `employee` (`emp_id`, `user_id`, `uname`, `email`, `position`) VALUES
(1, 1, 'Dharani', 'admin@gmail.com', 'Admin'),
(2, 2, 'Lakshmi ', 'rplakshmi@gmail.com', 'Receptionist'),
(3, 3, 'Orthopedic Dr.Sandeep ', 'drsandeep@gmail.com', 'Doctor'),
(4, 4, 'Karthick ', 'lbkarthick@gmail.com', 'Lab Technician'),
(5, 5, 'Durga', 'phdurga@gmail.com', 'Pharmasist'),
(6, 6, 'Immunologist Dr.Prem', 'drprem@gmail.com', 'Doctor'),
(7, 7, 'PCP Dr.Amaya', 'dramaya@gmail.com', 'Doctor'),
(8, 8, 'Cardiologist Dr.Renu', 'drrenu@gmail.com', 'Doctor');

-- --------------------------------------------------------

--
-- Table structure for table `lab_appoint`
--

CREATE TABLE `lab_appoint` (
  `id` int(11) NOT NULL,
  `patient_id` int(11) NOT NULL,
  `labtech_id` int(11) NOT NULL,
  `req_test` text NOT NULL,
  `e_date` date NOT NULL,
  `status` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `lab_appoint`
--

INSERT INTO `lab_appoint` (`id`, `patient_id`, `labtech_id`, `req_test`, `e_date`, `status`) VALUES
(1, 1, 4, 'Scan_Image', '2022-04-14', 1);

-- --------------------------------------------------------

--
-- Table structure for table `lab_results`
--

CREATE TABLE `lab_results` (
  `id` int(11) NOT NULL,
  `patient_id` int(11) NOT NULL,
  `malaria` varchar(30) NOT NULL,
  `typhoid` varchar(100) NOT NULL,
  `HIV/AIDs` varchar(100) NOT NULL,
  `blood_group` varchar(100) NOT NULL,
  `UTI` varchar(100) NOT NULL,
  `UTP` varchar(100) NOT NULL,
  `blood_pressure` varchar(100) NOT NULL,
  `weight` int(11) NOT NULL,
  `height` int(11) NOT NULL,
  `allergy` varchar(5) NOT NULL,
  `checked_by` varchar(100) NOT NULL,
  `scan_image` varchar(150) NOT NULL DEFAULT 'default-pic.jpg',
  `review` tinytext NOT NULL,
  `status` int(11) NOT NULL DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `lab_results`
--

INSERT INTO `lab_results` (`id`, `patient_id`, `malaria`, `typhoid`, `HIV/AIDs`, `blood_group`, `UTI`, `UTP`, `blood_pressure`, `weight`, `height`, `allergy`, `checked_by`, `scan_image`, `review`, `status`) VALUES
(1, 1, 'n/a', 'n/a', 'n/a', 'n/a', 'n/a', 'n/a', 'n/a', 0, 0, 'n/a', 'Karthick  M', 'Left Leg_Ankle Fracture.jpg', 'Scanned report shows that it is a Stable fracture only. This is the mildest form of fracture in which the broken ends of a bone line up and are hardly out of place, so it heals easily.', 1);

-- --------------------------------------------------------

--
-- Table structure for table `malipo`
--

CREATE TABLE `malipo` (
  `malipo_id` int(10) NOT NULL,
  `patient_id` int(11) NOT NULL,
  `amount` int(30) NOT NULL,
  `status` varchar(30) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `malipo`
--

INSERT INTO `malipo` (`malipo_id`, `patient_id`, `amount`, `status`) VALUES
(1, 1, 780, 'Paid');

-- --------------------------------------------------------

--
-- Table structure for table `medication`
--

CREATE TABLE `medication` (
  `id` int(10) NOT NULL,
  `patient_id` int(11) NOT NULL,
  `med_name` varchar(100) NOT NULL,
  `med_qty` int(11) NOT NULL,
  `dosage` text NOT NULL,
  `cost` int(11) NOT NULL,
  `comments` text NOT NULL,
  `md_date` date NOT NULL,
  `status` varchar(5) NOT NULL DEFAULT '0'
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `medication`
--

INSERT INTO `medication` (`id`, `patient_id`, `med_name`, `med_qty`, `dosage`, `cost`, `comments`, `md_date`, `status`) VALUES
(1, 1, 'Naproxen', 4, '500 mg', 240, 'Take one (500 mg) tablet every morning.', '2022-04-14', '1');

-- --------------------------------------------------------

--
-- Table structure for table `medicine`
--

CREATE TABLE `medicine` (
  `id` int(11) NOT NULL,
  `m_name` varchar(100) NOT NULL,
  `p_price` int(11) NOT NULL,
  `s_price` int(11) NOT NULL,
  `qty` int(11) NOT NULL,
  `added_by` varchar(100) NOT NULL,
  `added_at` date NOT NULL,
  `status` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `medicine`
--

INSERT INTO `medicine` (`id`, `m_name`, `p_price`, `s_price`, `qty`, `added_by`, `added_at`, `status`) VALUES
(1, 'Panadol', 90, 100, 1000, 'Durga V', '2022-01-19', 'active'),
(2, 'Mettacofline', 1000, 1200, 100, 'Durga V', '2022-01-19', 'active'),
(3, 'Cofta', 100, 150, 90, 'Durga V', '2022-01-19', 'active'),
(4, 'Acetaminophen', 180, 200, 200, 'Durga V', '2022-01-19', 'active'),
(5, 'Paracetamol', 140, 200, 120, 'Durga V', '2022-01-19', 'active'),
(6, 'Aspirin', 1800, 2000, 100, 'Durga V', '2022-01-19', 'active'),
(7, 'Whitedent', 2500, 3000, 150, 'Durga V', '2022-01-19', 'active'),
(8, 'Doxycycline', 1000, 1500, 100, 'Durga V', '2022-01-19', 'active'),
(9, 'Naproxen', 50, 60, 200, 'Durga V', '2022-01-20', 'active'),
(10, 'Amoxil ', 65, 80, 100, 'Durga V', '2022-04-05', 'active'),
(11, 'Cephalexin', 150, 200, 80, 'Durga V', '2022-04-05', 'active');

-- --------------------------------------------------------

--
-- Table structure for table `patient`
--

CREATE TABLE `patient` (
  `patient_id` int(11) NOT NULL,
  `fname` varchar(100) NOT NULL,
  `lname` varchar(25) NOT NULL,
  `status` varchar(100) NOT NULL,
  `regNumber` varchar(100) NOT NULL,
  `address` varchar(30) NOT NULL,
  `phone` varchar(15) NOT NULL,
  `email` varchar(30) NOT NULL,
  `dob` date NOT NULL,
  `gender` varchar(10) NOT NULL,
  `regDate` date NOT NULL,
  `treated` int(11) NOT NULL DEFAULT 0
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `patient`
--

INSERT INTO `patient` (`patient_id`, `fname`, `lname`, `status`, `regNumber`, `address`, `phone`, `email`, `dob`, `gender`, `regDate`, `treated`) VALUES
(1, 'Gokul', 'S', 'student', 'SRCAS-19101', 'Nava India, Coimbatore', '8888811111', 'ptgokul@gmail.com', '2001-01-01', 'male', '2022-04-14', 1);

-- --------------------------------------------------------

--
-- Table structure for table `sick_description`
--

CREATE TABLE `sick_description` (
  `id` int(11) NOT NULL,
  `patient_id` int(11) NOT NULL,
  `problem` varchar(100) NOT NULL,
  `since` date NOT NULL,
  `nature` varchar(100) NOT NULL,
  `checked_by` varchar(100) NOT NULL,
  `checked_date` date NOT NULL,
  `comment` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `sick_description`
--

INSERT INTO `sick_description` (`id`, `patient_id`, `problem`, `since`, `nature`, `checked_by`, `checked_date`, `comment`) VALUES
(1, 1, 'Leg Ankle  Pain', '2022-04-10', 'Fracture', 'Orthopedic Dr.Sandeep  K', '2022-04-14', 'The patient is injured with fracture. Take MRI scanning on his left leg ankle and send me the copy of the scanned image.');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `user_id` int(11) NOT NULL,
  `fname` varchar(25) NOT NULL,
  `lname` varchar(100) NOT NULL,
  `phone` varchar(30) NOT NULL,
  `email` varchar(30) NOT NULL,
  `password` varchar(30) NOT NULL,
  `status` varchar(20) NOT NULL,
  `date_reg` timestamp(6) NOT NULL DEFAULT current_timestamp(6) ON UPDATE current_timestamp(6),
  `position` int(10) NOT NULL,
  `last_login` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`user_id`, `fname`, `lname`, `phone`, `email`, `password`, `status`, `date_reg`, `position`, `last_login`) VALUES
(1, 'Dharani', 'M', '9999911111', 'admin@gmail.com', 'admin', 'Admin', '2022-04-14 06:10:57.293963', 2, '14th April, 2022 08:10:57 AM'),
(2, 'Lakshmi ', 'M', '9999922222', 'rplakshmi@gmail.com', 'HCMS123', 'Receptionist', '2022-04-14 06:39:12.529387', 1, '14th April, 2022 08:39:12 AM'),
(3, 'Orthopedic Dr.Sandeep ', 'K', '9999933333', 'drsandeep@gmail.com', 'HCMS123', 'Doctor', '2022-04-14 06:29:17.550558', 1, '14th April, 2022 08:29:17 AM'),
(4, 'Karthick ', 'M', '9999944444', 'lbkarthick@gmail.com', 'HCMS123', 'Lab Technician', '2022-04-14 06:38:32.278582', 1, '14th April, 2022 08:38:32 AM'),
(5, 'Durga', 'V', '9999955555', 'phdurga@gmail.com', 'HCMS123', 'Pharmasist', '2022-04-14 06:29:27.925398', 1, '14th April, 2022 08:29:27 AM'),
(6, 'Immunologist Dr.Prem', 'S', '9999966666', 'drprem@gmail.com', 'HCMS123', 'Doctor', '2022-04-13 12:48:17.000000', 1, ''),
(7, 'PCP Dr.Amaya', 'N', '9999977777', 'dramaya@gmail.com', 'HCMS123', 'Doctor', '2022-04-14 06:33:30.559409', 1, '14th April, 2022 08:02:20 AM'),
(8, 'Cardiologist Dr.Renu', 'V', '9999988888', 'drrenu@gmail.com', 'HCMS123', 'Doctor', '2022-04-13 12:50:40.000000', 1, '');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `appointments`
--
ALTER TABLE `appointments`
  ADD PRIMARY KEY (`appoint_id`);

--
-- Indexes for table `employee`
--
ALTER TABLE `employee`
  ADD PRIMARY KEY (`emp_id`);

--
-- Indexes for table `lab_appoint`
--
ALTER TABLE `lab_appoint`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `lab_results`
--
ALTER TABLE `lab_results`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `malipo`
--
ALTER TABLE `malipo`
  ADD PRIMARY KEY (`malipo_id`);

--
-- Indexes for table `medication`
--
ALTER TABLE `medication`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `medicine`
--
ALTER TABLE `medicine`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `patient`
--
ALTER TABLE `patient`
  ADD PRIMARY KEY (`patient_id`);

--
-- Indexes for table `sick_description`
--
ALTER TABLE `sick_description`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`user_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `appointments`
--
ALTER TABLE `appointments`
  MODIFY `appoint_id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `employee`
--
ALTER TABLE `employee`
  MODIFY `emp_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT for table `lab_appoint`
--
ALTER TABLE `lab_appoint`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `lab_results`
--
ALTER TABLE `lab_results`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `malipo`
--
ALTER TABLE `malipo`
  MODIFY `malipo_id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `medication`
--
ALTER TABLE `medication`
  MODIFY `id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `medicine`
--
ALTER TABLE `medicine`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;

--
-- AUTO_INCREMENT for table `patient`
--
ALTER TABLE `patient`
  MODIFY `patient_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `sick_description`
--
ALTER TABLE `sick_description`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `user_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
