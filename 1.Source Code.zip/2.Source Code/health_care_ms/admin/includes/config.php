<?php
$con=mysqli_connect("localhost","root","","hcmsdb");

if(mysqli_connect_errno()){

echo "Error".mysqli_connect_error();
}

?>